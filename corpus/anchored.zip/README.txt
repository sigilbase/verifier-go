Sigilbase evidence bundle
=========================

This bundle contains a tamper-evident export of audit events 1..20
from the stream "Conformance anchored" (conformance-anchored). Every event carries a SHA-256
hash chained to the previous event, and contiguous ranges are sealed into Merkle
checkpoints signed with Ed25519. Because verification recomputes every hash from
the data in this bundle and checks the signatures against the public keys in
manifest.json, you do not need to trust Sigilbase (or the party who exported
this bundle) to confirm that nothing was modified, deleted, or reordered after
ingestion.

To verify, run the bundled standalone verifier with PHP 8.2 or newer:

    php verify.php path/to/this-bundle.zip

(or extract the bundle and pass the directory). Exit code 0 means PASS.

anchors.json, when non-empty, holds RFC 3161 timestamp tokens from
third-party timestamping authorities over the checkpoint hashes: proof
the checkpoints existed at those times that not even Sigilbase can
forge retroactively. The verifier validates them when PHP's openssl
extension is available (pass --skip-anchors to skip). ca_pem entries
ship for convenience; for full independence, obtain the TSA's root
certificate yourself and compare.

consistency.json, present in bundles starting at sequence 1, records
the cumulative Merkle tree state at each checkpoint. Keep it: a later
export can then PROVE it extends this one without re-downloading
history — run php verify.php --consistency old.zip new.zip.

redactions.json declares any event in this range whose payload was
destroyed by the tenant (hash-preserving redaction, e.g. for personal
data recorded by mistake). A redacted event keeps its sequence, its
metadata, and every hash — the chain verifies unchanged, and the
preserved payload hash still convicts any "original" that resurfaces.
The verifier refuses any bundle where a payload is absent without a
declaration here: absence is always declared, never implied.

certificates/, when present, holds Certificates of Evidence issued
over records in this range — one-page summaries of what the
mathematics prove about a specific record. They are documents about
the evidence, not evidence themselves; manifest.json lists each
with its SHA-256 so you can confirm they travelled intact.